﻿using System;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Xml.Serialization;

namespace GameEncapsulationDemo
{
    public class Character
    {
        public string characterID;
        protected string characterName;
        internal string characterClass;
        private float health;
        private int level;
        private static int totalCharacterCount = 0;

        public static int getTotalCharacterCount()
        {
            return totalCharacterCount;
        }

        public Character()
        {
            characterID = "UNKNOWN";
            characterName = "Hero";
            characterClass = "Adventurer";
            health = 100;
            level = 1;
            totalCharacterCount++;
            Console.WriteLine("Objek Character dibuat dengan Konstruktor Default");
        }

        public Character(string id, string name)
        {
            characterID = id;
            characterName = name;
            characterClass = "Adventurer";
            health = 100;
            level = 1;
            totalCharacterCount++;
            Console.WriteLine($"Objek Character dibuat dengan Konstruktor Berparameter (ID & Nama).");
        }
        public Character(string id, string name, string classType)
        {
            characterID = id;
            characterName = name;
            characterClass = classType;
            health = 100;
            level = 1;
            totalCharacterCount++;
            Console.WriteLine($"Objek Character dibuat dengan Konstruktor Berparameter (ID, Nama, & Class).");
        }

        public void Start()
        {
            level = 1;
            health = 100;
            Console.WriteLine($"Karakter {characterName} (Level {level}) memulai pertualangan!");
        }

        private void LevelUp()
        {
            level++;
            Console.WriteLine($"{characterName} naik level! Level sekarang: {level}");
        }

        public void TakeDamage(float dmg)
        {
            health -= dmg;
            Console.WriteLine($"{characterName} menerima {dmg} damage. Health tersisa: {health}");
            if (health <= 0)
            {
                Console.WriteLine($"{characterName} telah gugur!");
            }
        }

        public void Heal(float healAmt)
        {
            health += healAmt;
            Console.WriteLine($"{characterName} sembuh sebesar {healAmt}. Health sekarang: {health}");
        }

        public void ShowStats()
        {
            Console.WriteLine("=== STATS KARAKTER ===");
            Console.WriteLine($"ID      : {characterID}");
            Console.WriteLine($"Nama    : {characterName}");
            Console.WriteLine($"Class   : {characterClass}");
            Console.WriteLine($"Level   : {level}");
            Console.WriteLine($"Health  : {health}");
            Console.WriteLine($"=====================\n");
        }
    }
}