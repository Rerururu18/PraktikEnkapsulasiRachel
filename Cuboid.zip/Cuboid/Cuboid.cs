﻿using System;
using System.Runtime.CompilerServices;

namespace Cuboid
{
    public class Cuboid
    {
        private float panjang;
        private float lebar;
        private float tinggi;
        private float volume;
        public static float jumVolumeTotal = 0;


        public Cuboid()
        {
            panjang = 10;
            lebar = 5;
            tinggi = 20;
            hitungVolume();
            tambahVolumeTotal(volume);
        }

        public Cuboid(float p, float l, float t)
        {
            panjang = p;
            lebar = l;
            tinggi = t;
            hitungVolume();
            tambahVolumeTotal(volume);
        }

        private void hitungVolume()
        {
            volume = panjang * lebar * tinggi;
        }

        public float getVolume()
        {
            return volume;
        }

        public static void tambahVolumeTotal(float v)
        {
            jumVolumeTotal += v;
        }

        public static float getJumVolumeTotal()
        {
            return jumVolumeTotal;
        }

        public void tampilData()
        {
            Console.WriteLine("======Data Balok======");
            Console.WriteLine($"Panjang balok: {panjang}");
            Console.WriteLine($"Lebar balok: {lebar}");
            Console.WriteLine($"Tinggi balok: {tinggi}");
            Console.WriteLine($"Volume balok: {getVolume()}");
            Console.WriteLine("======================\n");
        }
    }
}