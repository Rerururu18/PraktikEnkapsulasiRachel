using System;

namespace Cuboid
{
    class Program
    {
        static void Main(string[] args)
        {
            Cuboid balok1 = new Cuboid();
            Console.WriteLine("Balok 1");
            balok1.tampilData();

            Cuboid balok2 = new Cuboid(20, 10, 15);
            Console.WriteLine("Balok 2");
            balok2.tampilData();

            Cuboid balok3 = new Cuboid(67, 50, 100);
            Console.WriteLine("Balok 3");
            balok3.tampilData();

            Console.WriteLine($"Total Volume dari balok-balok: {Cuboid.getJumVolumeTotal()}");

            Console.ReadKey();
        }
    }
}